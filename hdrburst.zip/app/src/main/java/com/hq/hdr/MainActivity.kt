package com.hq.hdr

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.media.ImageReader
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var cm: CameraManager
    private lateinit var tv: TextureView
    private lateinit var frame: FrameLayout
    private lateinit var resultView: ImageView
    private lateinit var statusTv: TextView
    private lateinit var shutter: Button
    private lateinit var spreadSpin: Spinner
    private lateinit var tripodSw: Switch
    private lateinit var keepSw: Switch

    private var camId: String? = null
    private var chars: CameraCharacteristics? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var previewBuilder: CaptureRequest.Builder? = null

    @Volatile private var lastExp = 0L
    @Volatile private var lastIso = 0
    @Volatile private var lastAf = -1
    @Volatile private var shooting = false
    @Volatile private var waiting = false
    @Volatile private var burstId = 0
    private val got = ArrayList<ByteArray>()
    private var spread = 1.5
    private var tripod = false
    private var keep = true
    private var rotOffset = 0
    private var frameW = 0

    private lateinit var ht: HandlerThread
    private lateinit var h: Handler

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasCam() = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun status(s: String) = runOnUiThread { statusTv.text = s }

    private val previewCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            res.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { lastExp = it }
            res.get(CaptureResult.SENSOR_SENSITIVITY)?.let { lastIso = it }
            lastAf = res.get(CaptureResult.CONTROL_AF_STATE) ?: -1
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        ht = HandlerThread("cam").also { it.start() }
        h = Handler(ht.looper)
        buildUi()
        if (!hasCam()) requestPermissions(arrayOf(Manifest.permission.CAMERA), 1) else initCamera()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (hasCam()) initCamera() else status("Camera permission is needed. Allow it in Settings > Apps > HDR Burst.")
    }

    @SuppressLint("SetTextI18n")
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        tv = TextureView(this)
        frame.addView(tv, FrameLayout.LayoutParams(100, 100, Gravity.CENTER))
        resultView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            setOnClickListener { visibility = View.GONE }
        }
        frame.addView(resultView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addOnLayoutChangeListener { _, l, t, r, bt, _, _, _, _ -> fit(r - l, bt - t) }
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(14)) }
        statusTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = "Starting..." }
        spreadSpin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Exposure spread: small (-2 to +2 EV)", "Exposure spread: medium (-3 to +3 EV)", "Exposure spread: wide (-4 to +4 EV)"))
            setSelection(1)
        }
        tripodSw = Switch(this).apply { text = "Tripod mode (allow long exposures)"; setTextColor(Color.WHITE) }
        keepSw = Switch(this).apply { text = "Also save the 5 original shots"; isChecked = true; setTextColor(Color.WHITE) }
        val rotBtn = Button(this).apply {
            text = "Rotate preview (display only)"
            setOnClickListener { rotOffset = (rotOffset + 90) % 360; applyPreviewTransform() }
        }
        shutter = Button(this).apply {
            text = "TAKE 5-SHOT HDR"; isEnabled = false; textSize = 18f
            setOnClickListener { onShutter() }
        }
        panel.addView(statusTv); panel.addView(spreadSpin); panel.addView(tripodSw); panel.addView(keepSw)
        panel.addView(rotBtn); panel.addView(shutter)
        root.addView(panel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, hh: Int) {
                if (!hasCam()) return
                if (chars == null) initCamera() else if (device != null) startSession() else openCamera()
            }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, hh: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }

    private fun fit(fw: Int, fh: Int) {
        if (fw <= 0 || fh <= 0) return
        frameW = fw
        var w = fw
        var hh = w * 4 / 3
        if (hh > fh) { hh = fh; w = hh * 3 / 4 }
        val lp = tv.layoutParams
        if (lp.width != w || lp.height != hh) { lp.width = w; lp.height = hh; tv.layoutParams = lp }
        applyPreviewTransform()
    }

    private fun applyPreviewTransform() {
        tv.rotation = rotOffset.toFloat()
        val hh = tv.layoutParams.height
        val sc = if (rotOffset % 180 == 90 && hh > 0 && frameW > 0) Math.min(1f, frameW.toFloat() / hh) else 1f
        tv.scaleX = sc
        tv.scaleY = sc
    }

    private fun initCamera() {
        camId = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        val id = camId
        if (id == null) { status("No back camera found"); return }
        chars = cm.getCameraCharacteristics(id)
        if (tv.isAvailable) openCamera()
    }

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        val id = camId ?: return
        if (device != null || !hasCam()) return
        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) { device = d; startSession() }
                override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
                override fun onError(d: CameraDevice, e: Int) { d.close(); device = null; status("Camera error $e") }
            }, h)
        } catch (e: Exception) { status("Open failed: ${e.message}") }
    }

    private fun closeSession() {
        try { session?.close() } catch (e: Exception) {}
        session = null
        try { reader?.close() } catch (e: Exception) {}
        reader = null
    }

    private fun closeCamera() { closeSession(); try { device?.close() } catch (e: Exception) {}; device = null }

    private fun previewSize(): Size {
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val ss = map.getOutputSizes(SurfaceTexture::class.java)
        return ss.filter { Math.abs(it.width.toDouble() / it.height - 4.0 / 3.0) < 0.02 && it.width <= 1920 }
            .maxByOrNull { it.width } ?: ss[0]
    }

    private fun jpegSize(): Size {
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val ss = map.getOutputSizes(ImageFormat.JPEG)
        return ss.filter { Math.abs(it.width.toDouble() / it.height - 4.0 / 3.0) < 0.02 }
            .maxByOrNull { it.width.toLong() * it.height } ?: ss.maxByOrNull { it.width.toLong() * it.height }!!
    }

    private fun startSession() {
        val d = device ?: return
        val t = tv.surfaceTexture ?: return
        if (chars == null) return
        closeSession()
        try {
            val ps = previewSize()
            t.setDefaultBufferSize(ps.width, ps.height)
            val pSurf = Surface(t)
            val js = jpegSize()
            val rd = ImageReader.newInstance(js.width, js.height, ImageFormat.JPEG, 7)
            reader = rd
            rd.setOnImageAvailableListener({ r -> onImage(r) }, h)
            d.createCaptureSession(listOf(pSurf, rd.surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                        b.addTarget(pSurf)
                        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                        previewBuilder = b
                        s.setRepeatingRequest(b.build(), previewCb, h)
                        runOnUiThread { shutter.isEnabled = !shooting }
                        status("Ready. Photo size " + js.width + "x" + js.height + ". Hold still, then press the button.")
                    } catch (e: Exception) { status("Preview failed: ${e.message}") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { status("Camera setup failed") }
            }, h)
        } catch (e: Exception) { status("Setup failed: ${e.message}") }
    }

    private fun resumePreview() {
        val s = session ?: return
        val b = previewBuilder ?: return
        try {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL)
            s.capture(b.build(), previewCb, h)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
            s.setRepeatingRequest(b.build(), previewCb, h)
        } catch (e: Exception) {}
    }

    private fun fail(msg: String) {
        waiting = false
        shooting = false
        synchronized(got) { got.clear() }
        runOnUiThread { shutter.isEnabled = true }
        status(msg)
        resumePreview()
    }

    private fun onShutter() {
        if (shooting) return
        shooting = true
        shutter.isEnabled = false
        resultView.visibility = View.GONE
        spread = when (spreadSpin.selectedItemPosition) { 0 -> 1.0; 1 -> 1.5; else -> 2.0 }
        tripod = tripodSw.isChecked
        keep = keepSw.isChecked
        status("Focusing...")
        h.post { startAf() }
    }

    private fun startAf() {
        val s = session
        val b = previewBuilder
        if (s == null || b == null) { fail("Camera not ready"); return }
        try {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
            s.capture(b.build(), previewCb, h)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
            s.setRepeatingRequest(b.build(), previewCb, h)
            h.postDelayed({ pollAf(0) }, 350)
        } catch (e: Exception) { fail("Focus failed: ${e.message}") }
    }

    private fun pollAf(n: Int) {
        val st = lastAf
        if (n >= 20 || st == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED || st == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED) burst()
        else h.postDelayed({ pollAf(n + 1) }, 100)
    }

    private fun plan(t0: Long, iso0: Int, ev: Double): Pair<Long, Int> {
        val c = chars!!
        val tr = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)!!
        val ir = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)!!
        val cap = if (tripod) 1_000_000_000L else Math.max(t0, 125_000_000L)
        val g = Math.pow(2.0, ev)
        val hi = Math.min(tr.upper, cap)
        var t = (t0 * g).toLong()
        if (t < tr.lower) t = tr.lower
        if (t > hi) t = hi
        var iso = ((t0.toDouble() * iso0 * g) / t).toInt()
        if (iso < ir.lower) iso = ir.lower
        if (iso > ir.upper) iso = ir.upper
        return Pair(t, iso)
    }

    private fun burst() {
        val d = device
        val s = session
        val rd = reader
        val c = chars
        if (d == null || s == null || rd == null || c == null) { fail("Camera not ready"); return }
        val t0 = lastExp
        val iso0 = lastIso
        if (t0 <= 0L || iso0 <= 0) { fail("No exposure data from the camera yet. Try again."); return }
        try {
            val so = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            val maxFd = c.get(CameraCharacteristics.SENSOR_INFO_MAX_FRAME_DURATION) ?: Long.MAX_VALUE
            val list = ArrayList<CaptureRequest>()
            val info = StringBuilder()
            for (k in -2..2) {
                val ev = k * spread
                val p = plan(t0, iso0, ev)
                val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                b.addTarget(rd.surface)
                b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, p.first)
                b.set(CaptureRequest.SENSOR_SENSITIVITY, p.second)
                b.set(CaptureRequest.SENSOR_FRAME_DURATION, Math.min(maxFd, Math.max(p.first, 33_333_333L)))
                b.set(CaptureRequest.CONTROL_AWB_LOCK, true)
                b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
                b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF)
                b.set(CaptureRequest.JPEG_QUALITY, 98.toByte())
                b.set(CaptureRequest.JPEG_ORIENTATION, so)
                list.add(b.build())
                info.append(String.format("%+.1f EV: 1/%d s ISO %d\n", ev, Math.max(1L, Math.round(1e9 / p.first)), p.second))
            }
            synchronized(got) { got.clear() }
            waiting = true
            val token = ++burstId
            status("Shooting 5 frames. Keep the phone still...")
            val cb = object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureFailed(ss: CameraCaptureSession, r: CaptureRequest, f: CaptureFailure) {
                    if (waiting && burstId == token) fail("A shot failed. Try again (hold still, maybe a smaller spread).")
                }
            }
            s.captureBurst(list, cb, h)
            h.postDelayed({ if (waiting && burstId == token) fail("Timed out waiting for the shots.") }, 30000)
            lastPlan = info.toString()
        } catch (e: Exception) { fail("Burst failed: ${e.message}") }
    }

    private var lastPlan = ""

    private fun onImage(r: ImageReader) {
        val img = try { r.acquireNextImage() } catch (e: Exception) { null } ?: return
        val buf = img.planes[0].buffer
        val bytes = ByteArray(buf.remaining())
        buf.get(bytes)
        img.close()
        var ready: List<ByteArray>? = null
        synchronized(got) {
            if (!waiting) return
            got.add(bytes)
            if (got.size >= 5) { ready = ArrayList(got); got.clear() }
        }
        val rl = ready
        if (rl != null) {
            waiting = false
            resumePreview()
            val plan = lastPlan
            Thread { process(rl, plan) }.start()
        }
    }

    private fun saveBytes(bytes: ByteArray, name: String, path: String) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, path)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            val cv2 = ContentValues(); cv2.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, cv2, null, null)
        } catch (e: Exception) {}
    }

    private fun saveBitmap(bmp: Bitmap, name: String): Boolean {
        return try {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HDRBurst")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            val cv2 = ContentValues(); cv2.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, cv2, null, null)
            true
        } catch (e: Exception) { false }
    }

    private fun process(list: List<ByteArray>, plan: String) {
        val ts = System.currentTimeMillis()
        if (keep) for ((i, b) in list.withIndex()) saveBytes(b, "HDR_" + ts + "_" + (i + 1) + ".jpg", "Pictures/HDRBurst/Originals")
        status("Merging the 5 shots. This takes roughly 20 to 60 seconds...")
        var target = 2304
        var bmp: Bitmap? = null
        var err = ""
        while (bmp == null && target >= 1024) {
            try {
                bmp = Fusion.fuse(list, target) { m -> status(m + " (" + target + " px)") }
            } catch (e: Throwable) {
                err = e.javaClass.simpleName + " " + (e.message ?: "")
                target = (target * 0.7).toInt()
                System.gc()
            }
        }
        val result = bmp
        if (result == null) {
            shooting = false
            runOnUiThread { shutter.isEnabled = true }
            status("Merge failed: $err. " + (if (keep) "The 5 originals were saved." else ""))
            return
        }
        val ok = saveBitmap(result, "HDR_$ts.jpg")
        shooting = false
        runOnUiThread {
            resultView.setImageBitmap(result)
            resultView.visibility = View.VISIBLE
            shutter.isEnabled = true
            statusTv.text = (if (ok) "Saved to Pictures/HDRBurst (" + result.width + "x" + result.height + "). Tap the image to close.\n" else "Could not save the merged image.\n") + plan
        }
    }

    override fun onResume() {
        super.onResume()
        if (hasCam()) {
            if (chars == null) initCamera() else if (tv.isAvailable) openCamera()
        }
    }

    override fun onPause() {
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        ht.quitSafely()
        super.onDestroy()
    }
}
