package com.hq.hdr

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import java.nio.ByteBuffer
import java.util.stream.IntStream
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Exposure fusion (Mertens et al.): per-pixel quality weights blended through Laplacian pyramids. */
object Fusion {

    private fun par(n: Int, f: (Int) -> Unit) { IntStream.range(0, n).parallel().forEach { f(it) } }

    private fun blur(src: FloatArray, w: Int, h: Int, tmp: FloatArray, dst: FloatArray) {
        par(h) { y ->
            val o = y * w
            for (x in 0 until w) {
                val a = src[o + (if (x < 2) 0 else x - 2)]
                val b = src[o + (if (x < 1) 0 else x - 1)]
                val c = src[o + x]
                val d = src[o + (if (x + 1 >= w) w - 1 else x + 1)]
                val e = src[o + (if (x + 2 >= w) w - 1 else x + 2)]
                tmp[o + x] = (a + 4f * b + 6f * c + 4f * d + e) * 0.0625f
            }
        }
        par(h) { y ->
            val y0 = (if (y < 2) 0 else y - 2) * w
            val y1 = (if (y < 1) 0 else y - 1) * w
            val y2 = y * w
            val y3 = (if (y + 1 >= h) h - 1 else y + 1) * w
            val y4 = (if (y + 2 >= h) h - 1 else y + 2) * w
            for (x in 0 until w) {
                dst[y2 + x] = (tmp[y0 + x] + 4f * tmp[y1 + x] + 6f * tmp[y2 + x] + 4f * tmp[y3 + x] + tmp[y4 + x]) * 0.0625f
            }
        }
    }

    private fun down(src: FloatArray, w: Int, h: Int, ta: FloatArray, tb: FloatArray): FloatArray {
        blur(src, w, h, ta, tb)
        val nw = (w + 1) / 2
        val nh = (h + 1) / 2
        val out = FloatArray(nw * nh)
        par(nh) { y -> for (x in 0 until nw) out[y * nw + x] = tb[(2 * y) * w + 2 * x] }
        return out
    }

    private fun up(src: FloatArray, sw: Int, sh: Int, dst: FloatArray, dw: Int, dh: Int) {
        par(dh) { y ->
            val fy = (y + 0.5f) * sh / dh - 0.5f
            var y0 = Math.floor(fy.toDouble()).toInt()
            val ty = fy - y0
            var y1 = y0 + 1
            if (y0 < 0) y0 = 0
            if (y1 < 0) y1 = 0
            if (y0 > sh - 1) y0 = sh - 1
            if (y1 > sh - 1) y1 = sh - 1
            for (x in 0 until dw) {
                val fx = (x + 0.5f) * sw / dw - 0.5f
                var x0 = Math.floor(fx.toDouble()).toInt()
                val tx = fx - x0
                var x1 = x0 + 1
                if (x0 < 0) x0 = 0
                if (x1 < 0) x1 = 0
                if (x0 > sw - 1) x0 = sw - 1
                if (x1 > sw - 1) x1 = sw - 1
                val top = src[y0 * sw + x0] * (1f - tx) + src[y0 * sw + x1] * tx
                val bot = src[y1 * sw + x0] * (1f - tx) + src[y1 * sw + x1] * tx
                dst[y * dw + x] = top * (1f - ty) + bot * ty
            }
        }
    }

    private fun gaussPyr(base: FloatArray, sizes: List<IntArray>, ta: FloatArray, tb: FloatArray): Array<FloatArray> {
        val p = arrayOfNulls<FloatArray>(sizes.size)
        p[0] = base
        for (i in 1 until sizes.size) p[i] = down(p[i - 1]!!, sizes[i - 1][0], sizes[i - 1][1], ta, tb)
        return Array(sizes.size) { p[it]!! }
    }

    /** Quality weight: contrast x saturation x well-exposedness. gray is scratch. */
    private fun weight(r: FloatArray, g: FloatArray, b: FloatArray, w: Int, h: Int, gray: FloatArray, dst: FloatArray) {
        par(h) { y ->
            for (x in 0 until w) {
                val i = y * w + x
                gray[i] = 0.299f * r[i] + 0.587f * g[i] + 0.114f * b[i]
            }
        }
        par(h) { y ->
            val ym = (if (y < 1) 0 else y - 1) * w
            val yp = (if (y + 1 >= h) h - 1 else y + 1) * w
            val yc = y * w
            for (x in 0 until w) {
                val xm = if (x < 1) 0 else x - 1
                val xp = if (x + 1 >= w) w - 1 else x + 1
                val lap = gray[ym + x] + gray[yp + x] + gray[yc + xm] + gray[yc + xp] - 4f * gray[yc + x]
                val c = abs(lap)
                val i = yc + x
                val rr = r[i]
                val gg = g[i]
                val bb = b[i]
                val m = (rr + gg + bb) / 3f
                val s = sqrt(((rr - m) * (rr - m) + (gg - m) * (gg - m) + (bb - m) * (bb - m)) / 3f)
                val d0 = rr - 0.5f
                val d1 = gg - 0.5f
                val d2 = bb - 0.5f
                val e = exp(-(d0 * d0 + d1 * d1 + d2 * d2) / 0.08f)
                dst[i] = (c + 0.01f) * (s + 0.05f) * e + 1e-12f
            }
        }
    }

    fun decode(bytes: ByteArray, target: Int, fw: Int, fh: Int): Bitmap {
        var bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(bytes))) { dec, _, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
        val tw: Int
        val th: Int
        if (fw > 0) { tw = fw; th = fh } else {
            val sc = target.toFloat() / max(bmp.width, bmp.height)
            if (sc < 1f) { tw = (bmp.width * sc).roundToInt(); th = (bmp.height * sc).roundToInt() } else { tw = bmp.width; th = bmp.height }
        }
        if (tw != bmp.width || th != bmp.height) {
            val s = Bitmap.createScaledBitmap(bmp, tw, th, true)
            bmp.recycle()
            bmp = s
        }
        return bmp
    }

    fun fuse(srcs: List<ByteArray>, target: Int, progress: (String) -> Unit): Bitmap {
        val k = srcs.size
        val first = decode(srcs[0], target, 0, 0)
        val w = first.width
        val h = first.height
        val n = w * h
        val ch = Array(3) { FloatArray(n) }
        val ta = FloatArray(n)
        val tb = FloatArray(n)
        val px = IntArray(n)
        val sum = FloatArray(n)
        val weights = Array(k) { FloatArray(0) }

        fun load(bmp: Bitmap) {
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            par(h) { y ->
                for (x in 0 until w) {
                    val i = y * w + x
                    val p = px[i]
                    ch[0][i] = ((p shr 16) and 255) / 255f
                    ch[1][i] = ((p shr 8) and 255) / 255f
                    ch[2][i] = (p and 255) / 255f
                }
            }
        }

        for (i in 0 until k) {
            progress("Analysing shot ${i + 1} of $k")
            val bmp = if (i == 0) first else decode(srcs[i], target, w, h)
            load(bmp)
            bmp.recycle()
            val wt = FloatArray(n)
            weight(ch[0], ch[1], ch[2], w, h, ta, wt)
            weights[i] = wt
            par(h) { y -> for (x in 0 until w) sum[y * w + x] += wt[y * w + x] }
        }
        for (i in 0 until k) {
            val wt = weights[i]
            par(h) { y -> for (x in 0 until w) { val j = y * w + x; wt[j] = wt[j] / sum[j] } }
        }

        val sizes = ArrayList<IntArray>()
        var cw = w
        var chh = h
        sizes.add(intArrayOf(cw, chh))
        while (min(cw, chh) > 16 && sizes.size < 10) {
            cw = (cw + 1) / 2
            chh = (chh + 1) / 2
            sizes.add(intArrayOf(cw, chh))
        }
        val levels = sizes.size
        val out = Array(3) { Array(levels) { lv -> FloatArray(sizes[lv][0] * sizes[lv][1]) } }
        val u = FloatArray(n)

        for (i in 0 until k) {
            progress("Merging shot ${i + 1} of $k")
            val bmp = decode(srcs[i], target, w, h)
            load(bmp)
            bmp.recycle()
            val wp = gaussPyr(weights[i], sizes, ta, tb)
            for (c in 0 until 3) {
                val gp = gaussPyr(ch[c], sizes, ta, tb)
                for (lv in 0 until levels) {
                    val lw = sizes[lv][0]
                    val lh = sizes[lv][1]
                    val g = gp[lv]
                    val wl = wp[lv]
                    val o = out[c][lv]
                    if (lv < levels - 1) {
                        up(gp[lv + 1], sizes[lv + 1][0], sizes[lv + 1][1], u, lw, lh)
                        par(lh) { y -> for (x in 0 until lw) { val j = y * lw + x; o[j] += (g[j] - u[j]) * wl[j] } }
                    } else {
                        par(lh) { y -> for (x in 0 until lw) { val j = y * lw + x; o[j] += g[j] * wl[j] } }
                    }
                }
            }
            weights[i] = FloatArray(0)
        }

        progress("Finishing")
        val rc = Array(3) { FloatArray(0) }
        for (c in 0 until 3) {
            var cur = out[c][levels - 1]
            for (lv in levels - 2 downTo 0) {
                up(cur, sizes[lv + 1][0], sizes[lv + 1][1], u, sizes[lv][0], sizes[lv][1])
                val o = out[c][lv]
                val m = sizes[lv][0] * sizes[lv][1]
                for (p in 0 until m) o[p] += u[p]
                cur = o
            }
            rc[c] = cur
        }
        val result = IntArray(n)
        par(h) { y ->
            for (x in 0 until w) {
                val i = y * w + x
                val r = (rc[0][i].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                val g = (rc[1][i].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                val b = (rc[2][i].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                result[i] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(result, 0, w, 0, 0, w, h)
        return bmp
    }
}
